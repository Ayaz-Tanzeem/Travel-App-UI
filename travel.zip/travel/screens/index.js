import Dashboard from "./Dashboard"
import Place from "./Place"

export {
    Dashboard,
    Place
};
