import React from 'react';
import {View, Image, Text, TouchableOpacity, Animated, StatusBar, ScrollView, FlatList} from 'react-native';
import {dummyData, COLORS, SIZES, FONTS, icons, images} from '../constants'
import TextButton from '../components/textButton'

const Dashboard = ({ navigation }) => {

  const COUNTRIES_ITEM_SIZE = SIZES.width/3;
  const PLACES_ITEM_SIZE = SIZES.width/1.2;
  const EMPTY_ITEM_SIZE = (SIZES.width-PLACES_ITEM_SIZE)/2;

  const [countries, setCountries] = React.useState([{id: -1}, ...dummyData.countries, {id: -2}]);
  const countryScrollX = React.useRef(new Animated.Value(0)).current;

  function renderCountries() {
 
    return (
      <Animated.FlatList 
          horizontal
          pagingEnabled
          snapToAlignment="center"
          snapToInterval={COUNTRIES_ITEM_SIZE}
          showsHorizontalScrollIndicator={false}
          data={countries}
          decelerationRate={0}
          scrollEventThrottle={13}
          keyExtractor={item => item.id}  
          onMomentumScrollEnd={event => {
            var pos = (event.nativeEvent.contentOffset.x / COUNTRIES_ITEM_SIZE).toFixed(0);
            setPlaces([
              {id: -1},
              ...dummyData.countries[pos].places,
              {id: -2}
            ])
          }}    
          onScroll={Animated.event([{nativeEvent: {contentOffset: {x: countryScrollX}}}], {useNativeDriver: false})}    
          renderItem={({item, index}) => {

            const inputRange = [
                (index-2)*COUNTRIES_ITEM_SIZE,
                (index-1)*COUNTRIES_ITEM_SIZE,
                index*COUNTRIES_ITEM_SIZE
            ]

            const opacity = countryScrollX.interpolate({
              inputRange: inputRange,
              outputRange: [0.3, 1, 0.3],
              extrapolate: 'clamp'
            })

            const mapSize = countryScrollX.interpolate({
              inputRange: inputRange,
              outputRange: [25,60,25],
              extrapolate: 'clamp'
            })

            const fontSize = countryScrollX.interpolate({
              inputRange: inputRange,
              outputRange: [15,20,15],
              extrapolate: 'clamp'
            })

                      if(index==0 || index==countries.length-1) {
                        return (
                          <View style={{width: COUNTRIES_ITEM_SIZE}} />
                        )
                      }

                      else {
                        return (
                        <Animated.View style={{
                          height: 130,
                          width: COUNTRIES_ITEM_SIZE,
                          alignItems: 'center',
                          justifyContent: 'center',
                        }}>

                            <Animated.Image
                                source={item.image}
                                resizeMode="contain"
                                style={{
                                  width: mapSize,
                                  height: mapSize,
                                  tintColor: 'white',
                                  opacity
                                }}
                             />

                            <Animated.Text style={{marginTop: 3, color: 'white', opacity, fontSize}}>{item.name}</Animated.Text>

                        </Animated.View>
                        )
                      }

          }}          
      />
    )
  }


  const [places, setPlaces] = React.useState([{id: -1}, ...dummyData.countries[0].places, {id: -2}])
  const placesScrollX = React.useRef(new Animated.Value(0)).current;

  function renderPlaces() {
 
    return (
      <Animated.FlatList 
          horizontal
          pagingEnabled
          snapToAlignment="center"
          contentContainerStyle={{alignItems: 'center'}}
          snapToInterval={PLACES_ITEM_SIZE}
          data={places}
          bounces={false}
          showsHorizontalScrollIndicator={false}
          decelerationRate={0}
          scrollEventThrottle={13}
          keyExtractor={item => item.id}      
          onScroll={Animated.event([{nativeEvent: {contentOffset: {x: placesScrollX}}}], {useNativeDriver: false})}    
          renderItem={({item, index}) => {

            const inputRange = [
                (index-2)*PLACES_ITEM_SIZE,
                (index-1)*PLACES_ITEM_SIZE,
                index*PLACES_ITEM_SIZE
            ]

            const opacity = placesScrollX.interpolate({
              inputRange: inputRange,
              outputRange: [0.5, 1, 0.3],
              extrapolate: 'clamp'
            })

            let activeHeight = SIZES.height/1.6;
            let inactiveheight = SIZES.height/2.2;

            const height = placesScrollX.interpolate({
              inputRange: inputRange,
              outputRange: [inactiveheight,activeHeight,inactiveheight],
              extrapolate: 'clamp'
            })

                      if(index==0 || index==places.length-1) {
                        return (
                          <View style={{width: EMPTY_ITEM_SIZE}} />
                        )
                      }

                      else {
                        return (
                        <Animated.View style={{
                          opacity,
                          height,
                          width: PLACES_ITEM_SIZE,
                          alignItems: 'center',
                          borderRadius: 20,
                          padding: 10,
                        }}>
                            <Animated.Image
                                source={item.image}
                                resizeMode="cover"
                                style={{
                                  position: 'absolute',
                                  height: "100%",
                                  width: "100%",
                                  borderRadius: 20
                                }}
                             />

                             <View style={{flex: 1, alignItems: 'center', justifyContent: 'flex-end', marginHorizontal: SIZES.padding}}>
                                  <Text style={{marginBottom: 10, color: 'white', ...FONTS, fontSize: 30}}>{item.name}</Text>
                                  <Text style={{marginBottom: 30, color: 'white', ...FONTS, textAlign: 'center'}}>{item.description}</Text>

                             <TextButton onPress={() => {navigation.navigate("Place", {place: item})}} 
                                         buttonProps={{marginBottom: -10, width: 150}} 
                                         label={"Explore"} />
                             </View>
                             
                        </Animated.View>
                        )
                      }
          }}          
      />
    )
  }



    return (
        <View style={{ flex: 1, backgroundColor: 'black'}}>
            
            {/*Header*/}
            <View style={{
              flexDirection: 'row', 
              alignItems: 'center', 
              paddingHorizontal: SIZES.padding, 
              paddingVertical: SIZES.base, 
              justifyContent: 'space-between',
              marginTop: 30,
              }}>
                
                <View style={{height: 40, justifyContent: 'center', alignItems: 'center'}}>
                      <TouchableOpacity>
                          <Image source={icons.side_drawer} resizeMode="contain" style={{height: 25, width: 25, tintColor: 'white'}} />
                      </TouchableOpacity>
                </View>

                <View style={{flex: 1, alignItems: 'center', justifyContent: 'center'}}>
                      <Text style={{color: COLORS.white, fontSize: 15, ...FONTS}}>ASIA</Text>
                </View>

                <TouchableOpacity style={{alignItems: 'center', justifyContent: 'center'}}>
                      <Image source={images.profile_pic} resizeMode="contain" style={{height: 40, width: 40, borderRadius: 25}} />
                </TouchableOpacity>

            </View>



            <ScrollView>
                <View style={{flex: 1, height: 700}}>

                <View>
                    {renderCountries()}
                </View>

                <View style={{height: 500, backgroundColor: ' green', justifyContent: 'center'}}>
                    {renderPlaces()}
                </View>

                </View>
            </ScrollView>
            
            
        </View>
    )
}

export default Dashboard;