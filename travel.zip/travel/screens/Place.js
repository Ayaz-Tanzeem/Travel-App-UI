import React from 'react';
import {View, Text, ImageBackground, TouchableOpacity, Image, Animated} from 'react-native';
import SlidingUpPanel from 'rn-sliding-up-panel'
import MapView, {PROVIDER_GOOGLE, Marker} from 'react-native-maps'

import {SIZES, FONTS, icons} from '../constants'
import {TextButton, HeaderBar, Rating} from '../components'
import {MapStyle} from '../styles'

const Place = ({navigation, route}) => {

const [place, setPlace] = React.useState(null);
const [currentHotel, setCurrentHotel] = React.useState(null);
const [allowDragging, setAllowDragging] = React.useState(true);

let _panel = React.useRef(null);
const _draggedValue = React.useRef(new Animated.Value(0)).current;

React.useEffect(() => {
  let {place} = route.params;
  setPlace(place);

  _draggedValue.addListener((valueObj) => {
    if(valueObj.value > SIZES.height) setAllowDragging(false);
  })

  return () => {
    _draggedValue.removeAllListeners()
  }

}, []);

    return (
        <View style={{ flex: 1, justifyContent: 'center'}}>
            <ImageBackground source={place?.image} style={{width: "100%", height: "100%"}}>
                      
                      <HeaderBar customStyles={{position: 'absolute', top: SIZES.padding*2}} right={false}
                      leftIcon={icons.left_arrow} leftOnPress={()=>{navigation.goBack()}} />

                      <View style={{flex: 1, justifyContent: 'flex-end', padding: SIZES.padding, marginBottom: 80}}>

                          <View style={{flexDirection: 'row', justifyContent: 'space-between', alignItems: 'baseline'}}>

                              <Text style={{fontSize: 30, color: 'white'}}>{place?.name}</Text>

                              <View style={{flexDirection: 'row', alignItems: 'center'}}>
                                <Text style={{color: 'white', marginRight: 5}}>{place?.rate}</Text>
                                <Image source={icons.star} style={{height: 15, width: 15}} />
                              </View>

                          </View>

                          <Text style={{color: 'white', fontSize: 15, marginTop: 10}}>{place?.description}</Text>

                          <TextButton onPress={() => {}} 
                          buttonProps={{marginTop: SIZES.padding}} 
                          label={"Book Flights"} />

                      </View>

            </ImageBackground>

                      <SlidingUpPanel 
                        ref={c => (_panel = c)}
                        allowDragging={allowDragging}
                        draggableRange={{top: SIZES.height+135, bottom: 100}}
                        showBackdrop={false}
                        animatedValue={_draggedValue}
                        friction={0.7}
                        height={SIZES.height+135}
                        snappingPoints={[SIZES.height+135]}  
                        onBottomReached={() => {
                          setAllowDragging(true);
                        }}                      
                      >                      

                          <View style={{flex: 1, backgroundColor: 'transparent'}}>

                              <View style={{height: 100, backgroundColor: 'transparent', alignItems: 'center', justifyContent: 'center'}}>
                                <Image source={icons.up_arrow} style={{height: 15, width: 15, tintColor: 'white'}} />
                                <Text style={{fontSize: 15, color: 'white'}}>SWIPE UP FOR DETAILS</Text>
                              </View>

                              <View style={{flex: 1, backgroundColor: 'white'}}>
                                <MapView style={{width: "100%", height: "100%"}} provider={PROVIDER_GOOGLE}
                                 initialRegion={place?.mapInitialRegion} customMapStyle={MapStyle} >

                                 { 
                                   place?.hotels?.map((hotel, index) => (
                                    <Marker key={index} coordinate={hotel.latlng} identifier={hotel.id} onPress={()=>setCurrentHotel(hotel)}>
                                        <Image source={hotel.id == currentHotel?.id ? icons.bed_on : icons.bed_off} res="contain" style={{height: 50, width: 50}} />
                                    </Marker>
                                   ))}

                                </MapView>


                                <HeaderBar customStyles={{position: 'absolute', top: SIZES.padding*2}} 
                                           leftIcon={icons.left_arrow} leftOnPress={()=>_panel.hide()} 
                                           label={place?.name}
                                           right={true} rightIcon={icons.settings} />

                {currentHotel && <View style={{position: 'absolute', bottom: 0, padding: SIZES.radius}}>
                                   
                                    <Text style={{color: 'white', fontSize: 20}}>Hotels in {place?.name}</Text>

                                    <View style={{
                                      flexDirection: 'row',
                                      backgroundColor: 'black', 
                                      flex: 1,
                                      width: SIZES.width-2*SIZES.radius,
                                      borderRadius: 15, 
                                      marginTop: SIZES.radius,
                                      padding: SIZES.radius}}>

                                      <Image source={currentHotel?.image} resizeMode="cover" style={{height: 120, width: 100, borderRadius: 15}} />
                                      <View style={{flex: 1, justifyContent: 'space-between', marginLeft: SIZES.radius}}>
                                        <Text style={{fontSize: 18, color: 'white'}}>{currentHotel?.name}</Text>
                                        <Rating rate={currentHotel?.rate} />
                                        <View style={{flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center'}}>
                                          <TextButton textProps={{fontSize: 16}} label={"Details"} 
                                                      buttonProps={{height: 40, padding: SIZES.base+5, borderRadius: 5}} />
                                          <Text style={{color: 'white', fontSize: 15}}>From ${currentHotel?.price}</Text>
                                        </View>
                                      </View>

                                    </View>

                                </View>
                }

                              </View>

                          </View>

                      </SlidingUpPanel>

        </View>
    )
}

export default Place;