const profile_pic = require("../assets/images/profile_pic.jpg");

export default {
    profile_pic,
}