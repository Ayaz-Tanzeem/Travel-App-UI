import * as React from 'react'
import {Text, View, TouchableOpacity, Image} from 'react-native'
import {SIZES, icons} from '../constants'

export default function TextButton ({customStyles, rate})  {

  const arr = [];

  for(let i = 1; i <= 5; i++) {
      arr.push(
        <Image key={`full-${i}`} source={icons.star} resizeMode="cover" style={{
            height: 15, width: 15, 
            tintColor: i<rate?'gold':'grey',
            marginLeft: i==1?0:5,
        }} />
      )
  }

  return (
    <View style={{flexDirection: 'row', ...customStyles}}>
    {arr}
    </View>
  )
}
