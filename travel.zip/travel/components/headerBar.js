import * as React from 'react'
import {Text, View, TouchableOpacity, Image} from 'react-native'
import {SIZES, FONTS, icons} from '../constants'

export default function HeaderBar ({leftIcon, leftOnPress, label, rightIcon, rightOnPress, customStyles, textStyles, right})  {

  const styles = {
    height: 40, 
    width: 40, 
    borderRadius: 35, 
    justifyContent: 'center', 
    alignItems: 'center',
    backgroundColor: 'black', 
    opacity: 0.4
  }

  return (
    <View style={{flexDirection: 'row', width: SIZES.width-2*SIZES.padding, alignItems: 'center', justifyContent: "space-between", margin: SIZES.padding, ...customStyles}}>
      <TouchableOpacity style={styles} onPress={leftOnPress}>
        <Image source={leftIcon} resizeMode="contain" style={{height: 20, width: 20, tintColor: 'white'}} />
      </TouchableOpacity>

      <Text style={{color: 'white', fontSize: 20, ...textStyles}}>{label}</Text>

      {right &&
      <TouchableOpacity style={styles} onPress={rightOnPress}>
        <Image source={rightIcon} resizeMode="contain" style={{height: 20, width: 20, tintColor: 'white'}} />
      </TouchableOpacity>
      }
    </View>
  )

}
