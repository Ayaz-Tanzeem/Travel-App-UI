import * as React from 'react'
import {Text, View, TouchableOpacity} from 'react-native'
import {SIZES, FONTS} from '../constants'

export default function TextButton ({label, textProps, buttonProps, onPress})  {

  return (
    <TouchableOpacity onPress={onPress} style={{
      height: 40,
      alignItems: 'center',
      justifyContent: 'center',
      borderRadius: SIZES.radius,
      backgroundColor: 'white',
      ...buttonProps
    }}>
    <Text style={{fontSize: 18, ...textProps}}>{label}</Text>
    </TouchableOpacity>
  )
}
